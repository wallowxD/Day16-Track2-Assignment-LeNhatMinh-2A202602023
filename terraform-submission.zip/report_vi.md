# Báo cáo ngắn Lab 16 — AWS CPU + LightGBM

- Bộ dữ liệu Credit Card Fraud gồm 284.807 giao dịch; 227.845 dòng dùng train và 56.962 dòng dùng test.
- Thời gian đọc dữ liệu là 0,957 giây và thời gian huấn luyện LightGBM là 1,686 giây.
- Early stopping chọn best iteration = 1; dữ liệu mất cân bằng mạnh nên AUC/F1 có ý nghĩa hơn accuracy đơn lẻ.
- AUC-ROC đạt 0,95165 và accuracy đạt 0,99895.
- F1-score đạt 0,72727, precision 0,65574 và recall 0,81633.
- Median inference latency cho một dòng qua 100 lần đo là 0,538 ms.
- Batch 1.000 dòng mất 0,000788 giây, tương đương khoảng 1.269.332 dòng/giây trong phép đo ngắn này.
- Tài khoản chặn `t3.medium`; benchmark dùng `c7i-flex.large` Free Tier với cùng 2 vCPU/4 GiB RAM và kiến trúc x86_64.

